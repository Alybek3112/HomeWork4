package com.example.homework6;

public class ItemModel {

    String name;
    String name2;


    public ItemModel(String name, String name2) {
        this.name = name;
        this.name2 = name2;
    }
}
